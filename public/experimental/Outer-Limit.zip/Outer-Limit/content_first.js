
// document.documentElement. exsit 

//alert(document.documentElement.style.visibility);


document.documentElement.style.visibility = 'hidden';


  
