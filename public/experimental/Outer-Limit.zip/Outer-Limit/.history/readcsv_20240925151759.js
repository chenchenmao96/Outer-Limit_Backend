const fs = require('fs');
const csvParser = require('csv-parser');
const fetch = require('node-fetch'); // Ensure you have node-fetch installed

function read_csv() {
  // Store fake posts in a map for easy reference by fakepost_id
  const fakePosts = {};

  // Process fake posts first
  fs.createReadStream('fakepost.csv')
    .pipe(csvParser())
    .on('data', (rowData) => {
      const mappedPostData = {
        fakepost_id: rowData['fakepost_id'], // Unique ID for each post
        fakepost_url: rowData['fakepost_url'],
        fakepost_index: rowData['fakepost_index'],
        fakepost_title: rowData['fakepost_title'],
        fakepost_content: rowData['fakepost_content'],
        fakepost_image: rowData['fakepost_image'],
        fakepost_likes: rowData['fakepost_likes'],
        fakepost_time: rowData['fakepost_time'], 
        fakepost_community: rowData['fakepost_community'], 
        fakepost_poster: rowData['fakepost_poster']
      };

      // Add post to the fakePosts map for later reference
      fakePosts[mappedPostData.fakepost_id] = mappedPostData;

      // Send the fake post to the API
      fetch('https://outer.socialsandbox.xyz/api/createfakepost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mappedPostData)
      })
      .then(response => response.json())
      .then(data => { console.log('Fake post created:', data); })
      .catch(error => { console.error('Error creating fake post:', error); });
    })
    .on('end', () => { 
      console.log('CSV file successfully processed for fake posts'); 
      
      // After processing posts, process fake comments
      process_fake_comments(fakePosts);
    });
}

function process_fake_comments(fakePosts) {
  fs.createReadStream('fake_comment.csv')
    .pipe(csvParser())
    .on('data', (rowData) => {
      const mappedCommentData = {
        fake_comment_id: rowData['fake_comment_id'],
        fakepost_id: rowData['fakepost_id'], // Mapping comments to their respective fakepost_id
        user_name: rowData['user_name'],
        content: rowData['content'],
        likes: rowData['likes'],
        time: rowData['time'],
        profile: rowData['profile']
      };

      // Check if the fakepost_id exists in the posts map
      if (fakePosts[mappedCommentData.fakepost_id]) {
        // Send the comment to the API
        fetch(`https://outer.socialsandbox.xyz/api/addfakecomment/${mappedCommentData.fakepost_id}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(mappedCommentData)
        })
        .then(response => response.json())
        .then(data => { console.log('Fake comment created:', data); })
        .catch(error => { console.error('Error creating fake comment:', error); });
      } else {
        console.error(`Post with ID ${mappedCommentData.fakepost_id} not found.`);
      }
    })
    .on('end', () => { console.log('CSV file successfully processed for fake comments'); });
}

read_csv();