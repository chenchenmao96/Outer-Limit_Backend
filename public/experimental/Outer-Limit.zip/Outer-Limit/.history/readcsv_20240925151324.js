const fs = require('fs');
const csvParser = require('csv-parser');
const fetch = require('node-fetch'); // Ensure you have node-fetch installed

// Store fakepost_id mappings
const fakePostIdMap = {};

// Function to read fake posts first
function read_fake_posts() {
  return new Promise((resolve, reject) => {
    const posts = [];
    
    fs.createReadStream('fakepost.csv')
      .pipe(csvParser())
      .on('data', (rowData) => {
        const mappedData = {
            fakepost_id: rowData['fakepost_id'], // Assuming the post has a unique ID
            fakepost_url: rowData['fakepost_url'],
            fakepost_index: rowData['fakepost_index'],
            fakepost_title: rowData['fakepost_title'],
            fakepost_content: rowData['fakepost_content'],
            fakepost_image: rowData['fakepost_image'],
            fakepost_likes: rowData['fakepost_likes'],
            fakepost_time: rowData['fakepost_time'], 
            fakepost_community: rowData['fakepost_community'], 
            fakepost_poster: rowData['fakepost_poster']
        };

        posts.push(mappedData);

        // Store the URL to fakepost_id mapping
        fakePostIdMap[rowData['fakepost_url']] = rowData['fakepost_id'];

        console.log("Fake post mapped:", mappedData);

        // Insert the fake post via API
        fetch('https://outer.socialsandbox.xyz/api/createfakepost', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(mappedData)
        })
        .then(response => response.json())
        .then(data => { console.log('Fake post created:', data); })
        .catch(error => { console.error('Error creating fake post:', error); });
      })
      .on('end', () => { 
        console.log('CSV file successfully processed for fake posts'); 
        resolve(); // Resolve when done
      })
      .on('error', reject); // Reject if an error occurs
  });
}

// Function to read fake comments after posts are processed
function read_fake_comments() {
  return new Promise((resolve, reject) => {
    fs.createReadStream('fake_comment.csv')
      .pipe(csvParser())
      .on('data', (rowData) => {
        // Ensure that the fakepost_url has a corresponding fakepost_id
        const fakepost_id = fakePostIdMap[rowData['post_url']];
        if (!fakepost_id) {
          console.error(`No fakepost_id found for URL: ${rowData['post_url']}`);
          return;
        }

        const mappedData = {
            fake_comment_id: rowData['fake_comment_id'],
            user_name: rowData['user_name'],
            content: rowData['content'],
            likes: rowData['likes'],
            time: rowData['time'],
            profile: rowData['profile'],
            fakepost_id: fakepost_id // Map the comment to the corresponding fakepost_id
        };

        console.log("Fake comment mapped:", mappedData);

        // Insert the fake comment via API
        fetch(`https://outer.socialsandbox.xyz/api/addfakecomment/${fakepost_id}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(mappedData)
        })
        .then(response => response.json())
        .then(data => { console.log('Fake comment created:', data); })
        .catch(error => { console.error('Error creating fake comment:', error); });
      })
      .on('end', () => { 
        console.log('CSV file successfully processed for fake comments'); 
        resolve(); // Resolve when done
      })
      .on('error', reject); // Reject if an error occurs
  });
}

// Main function to handle the flow
async function process_csv_files() {
  try {
    await read_fake_posts();  // First, read and insert fake posts
    await read_fake_comments();  // Then, read and insert fake comments
    console.log("All posts and comments processed successfully.");
  } catch (error) {
    console.error("Error processing CSV files:", error);
  }
}

process_csv_files();