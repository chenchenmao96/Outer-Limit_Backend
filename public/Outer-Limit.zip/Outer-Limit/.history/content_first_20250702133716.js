
// document.documentElement. exsit 

//alert(document.documentElement.style.visibility);


//document.documentElement.style.visibility = 'hidden';

//document.documentElement.style.opacity = '0';

const hideStyle = document.createElement('style');
hideStyle.id = 'ext-hide-style';
hideStyle.textContent = `
  html, body { visibility: hidden !important; }
`;
document.head.appendChild(hideStyle);